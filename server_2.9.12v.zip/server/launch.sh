while true; do
  ./gtps
  exit_code=$?
  if [ $exit_code -ne 42 ]; then
    break
  fi
done
