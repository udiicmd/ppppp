-- Marvelous Missions script
print("(Loaded) Marvelous Missions script for GrowSoft")

local storageUniqueName = "marvelous-missions"
local marvelousData = {}

function loadData()
    print("Loading marvelous missions data")
    marvelousData = loadDataFromServer(storageUniqueName) or {}
end

loadData() -- Load the data once script is loaded

function saveData()
    print("Saving marvelous missions data")
    saveDataToServer(storageUniqueName, marvelousData)
end

onAutoSaveRequest(function() -- Happens each X minutes and on server shutdown
    saveData()
end)

function startsWith(str, start)
    return string.sub(str, 1, string.len(start)) == start
end

function formatNum(num)
    local formattedNum = tostring(num)
    formattedNum = formattedNum:reverse():gsub("(%d%d%d)", "%1,"):reverse()
    formattedNum = formattedNum:gsub("^,", "")
    return formattedNum
end

MissionsCat = {
    SEASON_1_MENU = 0,
    SEASON_2_MENU = 1
}

local missionsNavigation = {
    {name = "Season I", target = "tab_" .. MissionsCat.SEASON_1_MENU + 1, cat = MissionsCat.SEASON_1_MENU, texture = "interface/large/btn_mmtabs.rttex", texture_y = "1"},
    {name = "Season II", target = "tab_" .. MissionsCat.SEASON_2_MENU + 1, cat = MissionsCat.SEASON_2_MENU, texture = "interface/large/btn_mmtabs.rttex", texture_y = "2"}
}

MissionsTypes = {
    S1_FINDING_THE_SWAMP_MONSTER = 0,
    S1_HERE_COME_THE_SHADY_AGENTS = 1,
    S1_THE_SEARCH_FOR_NESSIE = 2,
    S1_MOTHMAN_RISING = 3,
    S1_THE_MENACE_OF_THE_MINI_MINOKAWA = 4,
    S1_THE_EYE_OF_THE_HEAVENS = 5,

    S2_A_TALE_OF_TENTACLES = 6,
    S2_THE_RAY_OF_THE_MANTA = 7,
    S2_THE_CRUST_OF_THE_CRAB = 8,
    S2_THE_CURSE_OF_THE_GHOST_PIRATE = 9,
    S2_THE_WINGS_OF_ATLANTIS = 10,
    S2_THE_HEART_OF_THE_OCEAN = 11
}

local missionsNames = {
    { type = MissionsTypes.S1_FINDING_THE_SWAMP_MONSTER, name = "Myths and Legends : Finding the Swamp monster!"},
    { type = MissionsTypes.S1_HERE_COME_THE_SHADY_AGENTS, name = "Myths and Legends : Here come the Shady Agents"},
    { type = MissionsTypes.S1_THE_SEARCH_FOR_NESSIE, name = "Myths and Legends : The Search for Nessie"},
    { type = MissionsTypes.S1_MOTHMAN_RISING, name = "Myths and Legends : Mothman Rising"},
    { type = MissionsTypes.S1_THE_MENACE_OF_THE_MINI_MINOKAWA, name = "Myths and Legends : The Menace of the Mini Minokawa"},
    { type = MissionsTypes.S1_THE_EYE_OF_THE_HEAVENS, name = "Myths and Legends : The Eye of the Heavens"},

    { type = MissionsTypes.S2_A_TALE_OF_TENTACLES, name = "The Seven Seas : A Tale of Tentacles!"},
    { type = MissionsTypes.S2_THE_RAY_OF_THE_MANTA, name = "The Seven Seas : The Ray of the Manta!"},
    { type = MissionsTypes.S2_THE_CRUST_OF_THE_CRAB, name = "The Seven Seas : The Crust of the Crab!"},
    { type = MissionsTypes.S2_THE_CURSE_OF_THE_GHOST_PIRATE, name = "The Seven Seas : The Curse of the Ghost Pirate!"},
    { type = MissionsTypes.S2_THE_WINGS_OF_ATLANTIS, name = "The Seven Seas : The Wings of Atlantis!"},
    { type = MissionsTypes.S2_THE_HEART_OF_THE_OCEAN, name = "The Seven Seas : The Heart of the Ocean!"}
}

function getMissionName(type)
    for i, mission in ipairs(missionsNames) do
        if mission.type == type then
            return mission.name
        end
    end
    return nil
end

local missionsData = { -- Note: I used getEnumItem() here, which is not needed, you can simply write item ID, i did this way so it's more readable
    {
        season = MissionsCat.SEASON_1_MENU,
        type = MissionsTypes.S1_FINDING_THE_SWAMP_MONSTER,
        requiredItems = {
            {
                itemID = getEnumItem("ITEM_PET_SLIME"):getID(),
                itemCount = 1
            },
            {
                itemID = getEnumItem("ITEM_SLIME_GREEN_HOODIE"):getID(),
                itemCount = 1
            },
            {
                itemID = getEnumItem("ITEM_AXOLOTL_HOOD"):getID(),
                itemCount = 2
            },
            {
                itemID = getEnumItem("ITEM_AXOLOTL_ONESIE"):getID(),
                itemCount = 2
            },
            {
                itemID = getEnumItem("ITEM_STRAWBERRY_SLIME_BLOCK"):getID(),
                itemCount = 200
            },
            {
                itemID = getEnumItem("ITEM_SLIP_N_SLIDE_SLIME_FLOOR"):getID(),
                itemCount = 100
            }
        },
        requiredMissions = {},
        rewardStr = "Reward: Swamp Monster Set + unlocks Here come the Shady Agents and The Search for Nessie",
        rewardItems = {
            {
                itemID = getEnumItem("ITEM_SWAMP_MONSTER_HEAD"):getID(),
                itemCount = 1
            },
            {
                itemID = getEnumItem("ITEM_SWAMP_MONSTER_ONESIE"):getID(),
                itemCount = 1
            }
        }
    },
    {
        season = MissionsCat.SEASON_1_MENU,
        type = MissionsTypes.S1_HERE_COME_THE_SHADY_AGENTS,
        requiredItems = {
            {
                itemID = getEnumItem("ITEM_STARFISH_LEASH"):getID(),
                itemCount = 1
            },
            {
                itemID = getEnumItem("ITEM_ZORBNIK_LEASH"):getID(),
                itemCount = 1
            },
            {
                itemID = getEnumItem("ITEM_FORGED_IRON_SKIN"):getID(),
                itemCount = 1
            },
            {
                itemID = getEnumItem("ITEM_SPACE_POOP"):getID(),
                itemCount = 200
            },
            {
                itemID = getEnumItem("ITEM_BLUE_STAR_SHOES"):getID(),
                itemCount = 100
            },
            {
                itemID = getEnumItem("ITEM_STARSEED"):getID(),
                itemCount = 10
            }
        },
        requiredMissions = { MissionsTypes.S1_FINDING_THE_SWAMP_MONSTER },
        rewardStr = "Reward: Shady Agent Shades  + unlocks Mothman Rising Mission",
        rewardItems = {
            {
                itemID = getEnumItem("ITEM_SHADY_AGENT_SHADES"):getID(),
                itemCount = 1
            }
        }
    },
    {
        season = MissionsCat.SEASON_1_MENU,
        type = MissionsTypes.S1_THE_SEARCH_FOR_NESSIE,
        requiredItems = {
            {
                itemID = getEnumItem("ITEM_RIDING_RV"):getID(),
                itemCount = 1
            },
            {
                itemID = getEnumItem("ITEM_CHICK_TRICYCLE"):getID(),
                itemCount = 1
            },
            {
                itemID = getEnumItem("ITEM_SURFBOARD_ELECTRIC_GREEN"):getID(),
                itemCount = 1
            },
            {
                itemID = getEnumItem("ITEM_BAGPIPES"):getID(),
                itemCount = 1
            },
            {
                itemID = getEnumItem("ITEM_WATER_BUCKET"):getID(),
                itemCount = 200
            },
            {
                itemID = getEnumItem("ITEM_RED_BICYCLE"):getID(),
                itemCount = 10
            }
        },
        requiredMissions = { MissionsTypes.S1_FINDING_THE_SWAMP_MONSTER },
        rewardStr = "Reward: Cardboard Nessie + unlocks The menace of the Mini Minokawa Mission",
        rewardItems = {
            {
                itemID = getEnumItem("ITEM_CARDBOARD_NESSIE"):getID(),
                itemCount = 1
            }
        }
    },
    {
        season = MissionsCat.SEASON_1_MENU,
        type = MissionsTypes.S1_MOTHMAN_RISING,
        requiredItems = {
            {
                itemID = getEnumItem("ITEM_FINIAS_RED_JAVELIN"):getID(),
                itemCount = 1
            },
            {
                itemID = getEnumItem("ITEM_NIGHTWINGS"):getID(),
                itemCount = 1
            },
            {
                itemID = getEnumItem("ITEM_TURKEY_WINGS"):getID(),
                itemCount = 1
            },
            {
                itemID = getEnumItem("ITEM_MEXICAN_HOT_SAUCE_ROCKET_PACK"):getID(),
                itemCount = 1
            },
            {
                itemID = getEnumItem("ITEM_DEVIL_WINGS"):getID(),
                itemCount = 1
            },
            {
                itemID = getEnumItem("ITEM_BLOOM_AURA"):getID(),
                itemCount = 1
            }
        },
        requiredMissions = { MissionsTypes.S1_HERE_COME_THE_SHADY_AGENTS },
        rewardStr = "Reward: Mothman Wings",
        rewardItems = {
            {
                itemID = getEnumItem("ITEM_MOTHMAN_WINGS"):getID(),
                itemCount = 1
            }
        }
    },
    {
        season = MissionsCat.SEASON_1_MENU,
        type = MissionsTypes.S1_THE_MENACE_OF_THE_MINI_MINOKAWA,
        requiredItems = {
            {
                itemID = getEnumItem("ITEM_POOKA_HOOD"):getID(),
                itemCount = 1
            },
            {
                itemID = getEnumItem("ITEM_MYSTIC_BATTLE_LANCE"):getID(),
                itemCount = 1
            },
            {
                itemID = getEnumItem("ITEM_RAVEN_WINGS"):getID(),
                itemCount = 1
            },
            {
                itemID = getEnumItem("ITEM_SUN_BLOCK"):getID(),
                itemCount = 100
            },
            {
                itemID = getEnumItem("ITEM_MOON_BLOCK"):getID(),
                itemCount = 100
            },
            {
                itemID = getEnumItem("ITEM_GOLDEN_AURA"):getID(),
                itemCount = 1
            }
        },
        requiredMissions = { MissionsTypes.S1_THE_SEARCH_FOR_NESSIE },
        rewardStr = "Reward: Mini Minokawa + unlocks The Eye of the Heavens",
        rewardItems = {
            {
                itemID = getEnumItem("ITEM_MINI_MINOKAWA"):getID(),
                itemCount = 1
            }
        }
    },
    {
        season = MissionsCat.SEASON_1_MENU,
        type = MissionsTypes.S1_THE_EYE_OF_THE_HEAVENS,
        requiredItems = {
            {
                itemID = getEnumItem("ITEM_DIAMONDENCRUSTED_DRAPED_FILIGREED_JADE_BLOCK"):getID(),
                itemCount = 200
            },
            {
                itemID = getEnumItem("ITEM_JADE_CRESCENT_AXE"):getID(),
                itemCount = 2
            },
            {
                itemID = getEnumItem("ITEM_BEOWULFS_HELM"):getID(),
                itemCount = 2
            },
            {
                itemID = getEnumItem("ITEM_CRYSTALIZED_STAR_FRAGMENT_BLOCK"):getID(),
                itemCount = 200
            },
            {
                itemID = getEnumItem("ITEM_SHAMROCK_SHURIKEN"):getID(),
                itemCount = 5
            },
            {
                itemID = getEnumItem("ITEM_MOON_WATCHER_MASK"):getID(),
                itemCount = 10
            }
        },
        requiredMissions = { MissionsTypes.S1_THE_MENACE_OF_THE_MINI_MINOKAWA },
        rewardStr = "Reward: Primordial Jade Lance",
        rewardItems = {
            {
                itemID = getEnumItem("ITEM_PRIMORDIAL_JADE_LANCE"):getID(),
                itemCount = 1
            }
        }
    },
    {
        season = MissionsCat.SEASON_2_MENU,
        type = MissionsTypes.S2_A_TALE_OF_TENTACLES,
        requiredItems = {
            {
                itemID = getEnumItem("ITEM_TENTACLE_BEARD"):getID(),
                itemCount = 100
            },
            {
                itemID = getEnumItem("ITEM_OCTOPUS_HEAD"):getID(),
                itemCount = 200
            },
            {
                itemID = getEnumItem("ITEM_SLITHERING_SERPENT_HAIR"):getID(),
                itemCount = 10
            },
            {
                itemID = getEnumItem("ITEM_DRUIDS_ROBES"):getID(),
                itemCount = 10
            },
            {
                itemID = getEnumItem("ITEM_GREG_THE_OCTOPUS"):getID(),
                itemCount = 1
            },
            {
                itemID = getEnumItem("ITEM_SUNFLOWER_DRESS"):getID(),
                itemCount = 10
            }
        },
        requiredMissions = {},
        rewardStr = "Reward: Robe of Tentacles + unlocks The Ray of the Manta and The Crust of the Crab",
        rewardItems = {
            {
                itemID = getEnumItem("ITEM_ROBE_OF_TENTACLES"):getID(),
                itemCount = 1
            }
        }
    },
    {
        season = MissionsCat.SEASON_2_MENU,
        type = MissionsTypes.S2_THE_RAY_OF_THE_MANTA,
        requiredItems = {
            {
                itemID = getEnumItem("ITEM_WEIRD_MANTA_RAY_LEASH"):getID(),
                itemCount = 10
            },
            {
                itemID = getEnumItem("ITEM_CUTE_MUTANT_PLONKY_ONESIE_HOOD"):getID(),
                itemCount = 2
            },
            {
                itemID = getEnumItem("ITEM_NEON_VOODOO_MASK_PLASMA_GREEN"):getID(),
                itemCount = 10
            },
            {
                itemID = getEnumItem("ITEM_PINEAPPLE_CORONET"):getID(),
                itemCount = 10
            },
            {
                itemID = getEnumItem("ITEM_BUNNY_EAR_MAGNIFYING_GLASS"):getID(),
                itemCount = 1
            },
            {
                itemID = getEnumItem("ITEM_UNAGI_HAIR"):getID(),
                itemCount = 20
            }
        },
        requiredMissions = { MissionsTypes.S2_A_TALE_OF_TENTACLES },
        rewardStr = "Reward: Neon Manta Ray + unlocks The Curse of the Ghost Pirate",
        rewardItems = {
            {
                itemID = getEnumItem("ITEM_NEON_MANTA_RAY"):getID(),
                itemCount = 1
            }
        }
    },
    {
        season = MissionsCat.SEASON_2_MENU,
        type = MissionsTypes.S2_THE_CRUST_OF_THE_CRAB,
        requiredItems = {
            {
                itemID = getEnumItem("ITEM_HERMIT_CRAB_LEASH"):getID(),
                itemCount = 1
            },
            {
                itemID = getEnumItem("ITEM_MAGIC_ARMOR_PLATE"):getID(),
                itemCount = 1
            },
            {
                itemID = getEnumItem("ITEM_STREET_SIDEWALK"):getID(),
                itemCount = 10
            },
            {
                itemID = getEnumItem("ITEM_TARANTULA_LEGS"):getID(),
                itemCount = 10
            },
            {
                itemID = getEnumItem("ITEM_PURPLE_SHORE_CRAB_HEADBAND"):getID(),
                itemCount = 1
            },
            {
                itemID = getEnumItem("ITEM_CRAB_CLAW_SHIELD"):getID(),
                itemCount = 1
            }
        },
        requiredMissions = { MissionsTypes.S2_A_TALE_OF_TENTACLES },
        rewardStr = "Reward: Cruising Crab + unlocks The Wings of Atlantis",
        rewardItems = {
            {
                itemID = getEnumItem("ITEM_CRUISIN_CRAB"):getID(),
                itemCount = 1
            }
        }
    },
    {
        season = MissionsCat.SEASON_2_MENU,
        type = MissionsTypes.S2_THE_CURSE_OF_THE_GHOST_PIRATE,
        requiredItems = {
            {
                itemID = getEnumItem("ITEM_FREEZING_SKULL_MASK"):getID(),
                itemCount = 10
            },
            {
                itemID = getEnumItem("ITEM_FIRE_PUNK_HAIR"):getID(),
                itemCount = 1
            },
            {
                itemID = getEnumItem("ITEM_SKULL_OF_BURNING_HORRORS"):getID(),
                itemCount = 1
            },
            {
                itemID = getEnumItem("ITEM_PRESIDENTIAL_BEARD"):getID(),
                itemCount = 10
            },
            {
                itemID = getEnumItem("ITEM_ELDRITCH_CROSSBOW"):getID(),
                itemCount = 1
            },
            {
                itemID = getEnumItem("ITEM_SEAFOAM_SCARF"):getID(),
                itemCount = 10
            }
        },
        requiredMissions = { MissionsTypes.S2_THE_RAY_OF_THE_MANTA },
        rewardStr = "Reward: Ghost Pirate Set + 1 of 2 requirements for The Heart of the Ocean",
        rewardItems = {
            {
                itemID = getEnumItem("ITEM_GHOST_PIRATE_HEAD"):getID(),
                itemCount = 1
            },
            {
                itemID = getEnumItem("ITEM_GHOST_PIRATE_SCIMITAR"):getID(),
                itemCount = 1
            }
        }
    },
    {
        season = MissionsCat.SEASON_2_MENU,
        type = MissionsTypes.S2_THE_WINGS_OF_ATLANTIS,
        requiredItems = {
            {
                itemID = getEnumItem("ITEM_PARTYDACTYL_WINGS"):getID(),
                itemCount = 2
            },
            {
                itemID = getEnumItem("ITEM_AQUAMARINE_STONE"):getID(),
                itemCount = 200
            },
            {
                itemID = getEnumItem("ITEM_GOLDFISH_BOWLER_HAT"):getID(),
                itemCount = 10
            },
            {
                itemID = getEnumItem("ITEM_POSEIDONS_TRIDENT"):getID(),
                itemCount = 1
            },
            {
                itemID = getEnumItem("ITEM_AQUA_CAVE_CRYSTAL"):getID(),
                itemCount = 200
            },
            {
                itemID = getEnumItem("ITEM_AMERICAN_EAGLE_WINGS"):getID(),
                itemCount = 1
            }
        },
        requiredMissions = { MissionsTypes.S2_THE_CRUST_OF_THE_CRAB },
        rewardStr = "Reward: Atlantean Wings + 1 of 2 requirements for The Heart of the Ocean",
        rewardItems = {
            {
                itemID = getEnumItem("ITEM_ATLANTEAN_WINGS"):getID(),
                itemCount = 1
            }
        }
    },
    {
        season = MissionsCat.SEASON_2_MENU,
        type = MissionsTypes.S2_THE_HEART_OF_THE_OCEAN,
        requiredItems = {
            {
                itemID = getEnumItem("ITEM_MATRIX_AURA"):getID(),
                itemCount = 1
            },
            {
                itemID = getEnumItem("ITEM_STAFF_OF_THE_DEEP"):getID(),
                itemCount = 20
            },
            {
                itemID = getEnumItem("ITEM_PINEAPPLE_CHAKRAM"):getID(),
                itemCount = 1
            },
            {
                itemID = getEnumItem("ITEM_YIN_YANG_PENDANT"):getID(),
                itemCount = 1
            },
            {
                itemID = getEnumItem("ITEM_CRYSTAL_AURA"):getID(),
                itemCount = 1
            },
            {
                itemID = getEnumItem("ITEM_NORTHERN_LIGHTS_AURA"):getID(),
                itemCount = 10
            }
        },
        requiredMissions = { MissionsTypes.S2_THE_CURSE_OF_THE_GHOST_PIRATE, MissionsTypes.S2_THE_WINGS_OF_ATLANTIS },
        rewardStr = "Reward: Oceanaura!",
        rewardItems = {
            {
                itemID = getEnumItem("ITEM_OCEANAURA"):getID(),
                itemCount = 1
            }
        }
    }
}

function isMissionComplete(player, type)
    local userData = marvelousData[player:getUserID()]

    if userData == nil then
        return false
    end

    for i, missionType in ipairs(userData.missionsComplete) do
        if missionType == type then
            return true
        end
    end
    return false
end

function isMissionAvailable(player, mission)
    if #mission.requiredMissions == 0 then
        return true
    end

    local userData = marvelousData[player:getUserID()]

    if userData == nil then
        return false
    end

    for _, requiredMission in ipairs(mission.requiredMissions) do
        local missionFound = false
        for _, completedMission in ipairs(userData.missionsComplete) do
            if completedMission == requiredMission then
                missionFound = true
                break
            end
        end
        if not missionFound then
            return false
        end
    end
    return true
end

function canClaim(player, mission)
    if not isMissionAvailable(player, mission) then
        return false
    end
    if isMissionComplete(player, mission.type) then
        return false
    end

    local hasAllItemsNeeded = true
    for i, item in ipairs(mission.requiredItems) do
        local hasAmount = player:getItemAmount(item.itemID)
        local hasEnough = hasAmount >= item.itemCount
        if not hasEnough then
            hasAllItemsNeeded = false
        end
    end
    return hasAllItemsNeeded
end

function onMarvelousMissions(world, player, cat)
    if cat < 0 or cat > 1 then
        return
    end

    local missionCategories = {}
    for i, category in ipairs(missionsNavigation) do
        local isCurrentCategory = (category.cat == cat) and "1" or "0"
        local tabString = string.format(
            "add_custom_button|%s|image:%s;image_size:228,92;frame:%s,%s;width:0.15;min_width:60;|",
            category.target,
            category.texture,
            isCurrentCategory,
            category.texture_y
        )
        table.insert(missionCategories, tabString)
    end

    local availableMissions = {}

    for i, mission in ipairs(missionsData) do
        if mission.season == cat then
            local hasAllItemsNeeded = true
            local isMissionComplete = isMissionComplete(player, mission.type)
            local isMissionAvailable = isMissionAvailable(player, mission)
            table.insert(availableMissions, "add_spacer|small|")
            table.insert(availableMissions, "add_spacer|small|")
            table.insert(availableMissions, string.format("add_custom_textbox|%s|size:medium;color:255,255,255,%s|", getMissionName(mission.type), (isMissionAvailable == true) and "255" or "80"))
            for x, item in ipairs(mission.requiredItems) do
                local hasAmount = player:getItemAmount(item.itemID)
                local hasEnough = hasAmount >= item.itemCount
                if not hasEnough then
                    hasAllItemsNeeded = false
                end
                table.insert(availableMissions, string.format("add_button_with_icon|info_%s|%s%s/%s`|staticGreyFrame,no_padding_x,is_count_label,%s|%s||", item.itemID, (hasEnough == true) and "`2" or "`4", hasAmount, item.itemCount, (isMissionAvailable == true) and "" or ",disabled", item.itemID))
            end
            table.insert(availableMissions, "add_button_with_icon||END_LIST|noflags|0||")
            table.insert(availableMissions, string.format("add_custom_textbox|`$%s`|size:small;color:255,255,255,%s", mission.rewardStr, (isMissionAvailable == true) and "255" or "80"))
            for x, item in ipairs(mission.rewardItems) do
                table.insert(availableMissions, string.format("add_button_with_icon|info_%s||staticYellowFrame,no_padding_x,%s|%s|%s|", item.itemID, (isMissionAvailable == true) and "" or ",disabled", item.itemID, item.itemCount))
            end
            table.insert(availableMissions, "add_button_with_icon||END_LIST|noflags|0||")
            table.insert(availableMissions, "add_spacer|small|")
            if isMissionComplete then
                table.insert(availableMissions, string.format("add_button|claim_myth_%s|Claimed|off|0|0|", mission.type))
            elseif hasAllItemsNeeded and isMissionAvailable then
                table.insert(availableMissions, string.format("add_button|claim_myth_%s|Claim|noflags|0|0|", mission.type))
            else
                table.insert(availableMissions, string.format("add_button|claim_myth_%s|Claim|off|0|0|", mission.type))
            end
        end
    end

    if cat == MissionsCat.SEASON_2_MENU then -- Aqua Color style
        player:setNextDialogRGBA(59, 130, 135, 168) -- Change color of the dialog's background
        player:setNextDialogBorderRGBA(0, 255, 255, 255) -- Change color of the dialog's border
    else -- Purple Color style
        player:setNextDialogRGBA(46, 26, 105, 168) -- Change color of the dialog's background
        player:setNextDialogBorderRGBA(65, 2, 250, 255) -- Change color of the dialog's border
    end

    player:onDialogRequest(
        "set_default_color|`o\n" ..
        "start_custom_tabs|\n" ..
        table.concat(missionCategories, "\n") .. "\n" ..
        "end_custom_tabs|\n" ..
        "add_label_with_icon|big|`wMarvelous Missions``|left|982|\n" ..
        "embed_data|tab|" .. cat .. "\n" ..
        "add_spacer|small|\n" ..
        "add_textbox|Start your mission towards some awesome rewards. Unless the mission states otherwise, rewards can only be claimed once. Some rewards are only available through events or certain times of the year so make sure to check back to see what's available.|left|\n" ..
        table.concat(availableMissions, "\n") .. "\n" ..
        "add_spacer|small|\n" ..
        "add_textbox|More missions coming soon! Check back for some more surprises!|left|\n" ..
        "add_spacer|small|\n" ..
        "add_button|back|Back|noflags|0|0|\n" ..
        "end_dialog|collectionQuests|||\n" ..
        "add_quick_exit|", 500 -- 500 is ms delay, its needed because otherwise dialogs with tabs kinda gets cursed in Growtopia, yes the delay is annoying, hopefuly in future gt will fix their issues
    )

    player:resetDialogColor() -- Reset the color (important)
end

onPlayerDialogCallback(function(world, player, data)
    local dialogName = data["dialog_name"] or ""
    if dialogName == "collectionQuests" then
        if data["buttonClicked"] ~= nil then
            if data["buttonClicked"] == "back" then
                player:onProfileUI(world, 1)
                return true
            end
            if startsWith(data["buttonClicked"], "tab_") then
                local tabNum = tonumber(data["buttonClicked"]:sub(5))
                onMarvelousMissions(world, player, tabNum - 1)
                return true
            end
            if startsWith(data["buttonClicked"], "claim_myth_") then
                local missionType = tonumber(string.sub(data["buttonClicked"], 12))
                for i, mission in ipairs(missionsData) do
                    if mission.type == missionType then
                        if not canClaim(player, mission) then
                            return true
                        end
                        if data["confirmClaim"] ~= nil then
                            for i, item in ipairs(mission.requiredItems) do
                                player:changeItem(item.itemID, -item.itemCount, 0)
                            end
                            for i, item in ipairs(mission.rewardItems) do
                                if not player:changeItem(item.itemID, item.itemCount, 0) then
                                    player:changeItem(item.itemID, item.itemCount, 1)
                                end
                            end
                            player:onAddNotification("", "`$Mission Complete!``", "", 0, 1500) -- texture, message, audio and the last is delay
                            -- player middle pos is like the very middle of a player sprite
                            local playerMiddlePosX = player:getMiddlePosX()
                            local playerMiddlePosY = player:getMiddlePosY()
                            local players = world:getPlayers()
                            for i = 1, #players do -- Show the particle effect to everyone in a world
                                local itPlayer = players[i]
                                itPlayer:onParticleEffect(46, playerMiddlePosX, playerMiddlePosY, 0, 0)
                            end
                            if not marvelousData[player:getUserID()] then
                                marvelousData[player:getUserID()] = { missionsComplete = { mission.type } }
                            else
                                table.insert(marvelousData[player:getUserID()].missionsComplete, mission.type)
                            end
                            return true
                        end
                        player:onDialogRequest(
                            "set_default_color|`o\n" ..
                            "add_label|big|Marvelous Mission|left|\n" ..
                            "embed_data|tab|" .. string.sub(data["tab"], 1, -2) .. "\n" ..
                            "embed_data|confirmClaim|1\n" ..
                            "add_spacer|small|\n" ..
                            "add_textbox|By selecting claim, the items will be removed from your inventory and your reward will be added.|left|\n" ..
                            "add_spacer|small|\n" ..
                            "add_button|" .. data["buttonClicked"] .. "|Claim|noflags|0|0|\n" ..
                            "end_dialog|collectionQuests||Back|", 500
                        )
                        return true
                    end
                end
                return true
            end
            if startsWith(data["buttonClicked"], "info_") then
                local itemID = tonumber(string.sub(data["buttonClicked"], 6))
                local item = getItem(itemID)
                if item == nil then
                    return true
                end
                local itemInfo = item:getInfo()
                local itemInfoArray = {}
                for i, info in ipairs(itemInfo) do
                    table.insert(itemInfoArray, string.format("add_textbox|%s|left|", info))
                end
                if #itemInfoArray > 0 then
                    table.insert(itemInfoArray, "add_spacer|small|")
                end
                player:onDialogRequest(
                    "set_default_color|`o\n" ..
                    "add_label_with_icon|big|`wAbout " .. item:getName() .. "``|left|" .. item:getID() .. "|\n" ..
                    "embed_data|tab|" .. string.sub(data["tab"], 1, -2) .. "\n" ..
                    "add_spacer|small|\n" ..
                    "add_textbox|" .. item:getDescription() .. "|left|\n" ..
                    "add_spacer|small|\n" ..
                    table.concat(itemInfoArray, "\n") .. "\n" ..
                    "end_dialog|collectionQuests|Close|Back|", 500
                )
                return true
            end
            return true
        end
        if data["tab"] ~= nil then
            onMarvelousMissions(world, player, tonumber(string.sub(data["tab"], 1, -2)))
            return true
        end
        return true
    end
    if dialogName == "playerProfile" then
        if data["buttonClicked"] ~= nil then
            if data["buttonClicked"] == "marvelous_missions" then
                onMarvelousMissions(world, player, MissionsCat.SEASON_1_MENU)
                return true
            end
        end
        return false
    end
    return false
end)