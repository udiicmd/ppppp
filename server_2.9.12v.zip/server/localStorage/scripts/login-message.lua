-- Login Message script
print("(Loaded) Login Message script for GrowSoft")

onPlayerLoginCallback(function(player)
    player:onConsoleMessage("`2Welcome to awesome GTPS``")
end)
