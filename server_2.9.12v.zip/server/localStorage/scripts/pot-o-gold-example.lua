-- Pot-O-Gold Gems Drop Example script
print("(Loaded) Pot-O-Gold Gems Drop Example script for GrowSoft")

math.randomseed(os.time())

onTileBreakCallback(function(world, player, tile)
    local tileID = tile:getTileID();
    if tileID == 542 then -- Pot O' Gold
        world:spawnGems(tile:getPosX(), tile:getPosY(), math.random(1, 100))
        return true
    end
    return false
end)
